This module allows you to add a hidden UNIX timestamp component to any webform.
